# Dawn Mobile

Clean, legitimate Minecraft client modules inspired by Dawn Client.  
No cheats (no Kill Aura, Fly, Scaffold, etc.).

**Target:** Minecraft 1.21.11 + Fabric

## Included in this starter (Batch B)

- **Color Saturation** (Visuals) – Dawn-style saturation / contrast / brightness / hue / grayscale
- **FPS** (HUD)
- **CPS** (HUD)
- **Toggle Sprint** (PvP / Utility)
- **Zoom** (PvP / Utility) – hold C by default
- **Fullbright** (Visuals)

## Building the JAR

### Requirements
- Java 21
- Git (optional)

### Steps

```bash
cd dawn-mobile
./gradlew build
```

The finished JAR will be in:

```
build/libs/dawn-mobile-0.1.0.jar
```

Drop that JAR into your `mods` folder (Fabric 1.21.11) or into a mobile launcher that supports Fabric mods (e.g. Zalith).

### First run notes
- Right Shift opens a placeholder GUI log message (full ClickGUI comes later).
- Zoom key is **C** (changeable in Controls).
- FPS and CPS are enabled by default.
- Color Saturation, Toggle Sprint, Zoom and Fullbright start disabled — enable them from code or later GUI.

## Project structure

```
src/main/java/com/dawnmobile/
  client/          → Main client entrypoint
  module/          → Module base + manager
  module/impl/     → Actual modules
  mixin/client/    → Mixins (hooks)
```

## Next steps you can request
- Full ClickGUI (Dawn-style, touch-friendly)
- More HUD modules (Coordinates, Armor Status, Keystrokes…)
- Proper post-process shader for Color Saturation
- Config file (save enabled state + slider values)
- Mobile performance presets

## License
MIT (feel free to expand)
