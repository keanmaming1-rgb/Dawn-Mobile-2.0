package com.dawnmobile.client;

import com.dawnmobile.module.ModuleManager;
import com.dawnmobile.module.impl.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DawnMobileClient implements ClientModInitializer {
    public static final String MOD_ID = "dawnmobile";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static ModuleManager moduleManager;
    public static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        LOGGER.info("Dawn Mobile initializing for 1.21.11");

        moduleManager = new ModuleManager();

        // Register modules (Batch B)
        moduleManager.register(new ColorSaturationModule());
        moduleManager.register(new FpsHudModule());
        moduleManager.register(new CpsHudModule());
        moduleManager.register(new ToggleSprintModule());
        moduleManager.register(new ZoomModule());
        moduleManager.register(new FullbrightModule());

        // Keybind to open simple module list (placeholder for ClickGUI)
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dawnmobile.opengui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.dawnmobile"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openGuiKey.wasPressed()) {
                // Placeholder: later open ClickGUI
                LOGGER.info("Dawn Mobile GUI key pressed (ClickGUI coming later)");
            }
            moduleManager.onTick(client);
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            moduleManager.onHudRender(drawContext, tickCounter.getTickDelta(false));
        });

        LOGGER.info("Dawn Mobile loaded with {} modules", moduleManager.getModules().size());
    }
}
