package com.dawnmobile.module.impl;

import com.dawnmobile.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public class FullbrightModule extends Module {

    private double previousGamma = 1.0;

    public FullbrightModule() {
        super("Fullbright", "Maximum brightness / night vision style visibility", Category.VISUALS);
    }

    @Override
    protected void onEnable() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.options != null) {
            previousGamma = client.options.getGamma().getValue();
            client.options.getGamma().setValue(16.0); // very high gamma
        }
    }

    @Override
    protected void onDisable() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.options != null) {
            client.options.getGamma().setValue(previousGamma);
        }
        if (client != null && client.player != null) {
            client.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    @Override
    public void onTick(MinecraftClient client) {
        // Optional: also apply night vision for caves
        if (client.player != null && isEnabled()) {
            client.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 220, 0, false, false, false));
        }
    }
}
