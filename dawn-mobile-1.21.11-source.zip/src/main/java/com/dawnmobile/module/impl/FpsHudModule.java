package com.dawnmobile.module.impl;

import com.dawnmobile.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class FpsHudModule extends Module {

    public int x = 4;
    public int y = 4;
    public boolean shadow = true;

    public FpsHudModule() {
        super("FPS", "Shows current frames per second on screen", Category.HUD);
        setEnabled(true); // on by default
    }

    @Override
    public void onHudRender(DrawContext context, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) return;

        String text = client.getCurrentFps() + " FPS";
        int color = 0xFFFFFF;

        if (shadow) {
            context.drawTextWithShadow(client.textRenderer, text, x, y, color);
        } else {
            context.drawText(client.textRenderer, text, x, y, color, false);
        }
    }
}
