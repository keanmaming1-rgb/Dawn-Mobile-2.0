package com.dawnmobile.module.impl;

import com.dawnmobile.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;

public class ToggleSprintModule extends Module {

    public ToggleSprintModule() {
        super("Toggle Sprint", "Keeps sprint active when the sprint key is toggled", Category.PVP);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null) return;

        KeyBinding sprintKey = client.options.sprintKey;

        // Simple persistent sprint while module is enabled
        // (A more advanced version would track a toggle state on key press)
        if (!client.player.isSprinting() && client.player.forwardSpeed > 0 && !client.player.isSneaking()) {
            client.player.setSprinting(true);
        }
    }
}
