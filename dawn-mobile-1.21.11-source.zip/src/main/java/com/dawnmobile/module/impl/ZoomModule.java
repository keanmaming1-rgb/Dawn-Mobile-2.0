package com.dawnmobile.module.impl;

import com.dawnmobile.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import org.lwjgl.glfw.GLFW;

public class ZoomModule extends Module {

    public static KeyBinding zoomKey;
    public float zoomFactor = 0.3f; // lower = more zoom
    private boolean wasZooming = false;
    private double originalFov = 70.0;

    public ZoomModule() {
        super("Zoom", "Hold a key to zoom in (optical zoom style)", Category.PVP);

        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dawnmobile.zoom",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_C,
                "category.dawnmobile"
        ));
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client == null || client.options == null) return;

        boolean zooming = zoomKey.isPressed() && isEnabled();

        if (zooming && !wasZooming) {
            originalFov = client.options.getFov().getValue();
            client.options.getFov().setValue((int) (originalFov * zoomFactor));
        } else if (!zooming && wasZooming) {
            client.options.getFov().setValue((int) originalFov);
        }

        wasZooming = zooming;
    }

    @Override
    protected void onDisable() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.options != null && wasZooming) {
            client.options.getFov().setValue((int) originalFov);
            wasZooming = false;
        }
    }
}
