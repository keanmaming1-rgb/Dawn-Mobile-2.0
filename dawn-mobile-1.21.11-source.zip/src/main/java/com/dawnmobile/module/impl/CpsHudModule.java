package com.dawnmobile.module.impl;

import com.dawnmobile.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CpsHudModule extends Module {

    public int x = 4;
    public int y = 14;
    public boolean shadow = true;

    private final List<Long> leftClicks = new ArrayList<>();
    private final List<Long> rightClicks = new ArrayList<>();
    private boolean wasLeftPressed = false;
    private boolean wasRightPressed = false;

    public CpsHudModule() {
        super("CPS", "Shows clicks per second (left / right)", Category.HUD);
        setEnabled(true);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client == null || client.getWindow() == null) return;

        long handle = client.getWindow().getHandle();
        long now = System.currentTimeMillis();

        boolean left = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean right = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;

        if (left && !wasLeftPressed) {
            leftClicks.add(now);
        }
        if (right && !wasRightPressed) {
            rightClicks.add(now);
        }

        wasLeftPressed = left;
        wasRightPressed = right;

        // Remove clicks older than 1 second
        clean(leftClicks, now);
        clean(rightClicks, now);
    }

    private void clean(List<Long> list, long now) {
        Iterator<Long> it = list.iterator();
        while (it.hasNext()) {
            if (now - it.next() > 1000) it.remove();
        }
    }

    @Override
    public void onHudRender(DrawContext context, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) return;

        String text = leftClicks.size() + " | " + rightClicks.size() + " CPS";
        int color = 0xFFFFFF;

        if (shadow) {
            context.drawTextWithShadow(client.textRenderer, text, x, y, color);
        } else {
            context.drawText(client.textRenderer, text, x, y, color, false);
        }
    }
}
