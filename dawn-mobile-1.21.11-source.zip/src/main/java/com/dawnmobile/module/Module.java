package com.dawnmobile.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public abstract class Module {
    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled;

    public Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.enabled = false;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean enabled) {
        if (this.enabled == enabled) return;
        this.enabled = enabled;
        if (enabled) onEnable();
        else onDisable();
    }

    public boolean isEnabled() {
        return enabled;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public Category getCategory() {
        return category;
    }

    protected void onEnable() {}
    protected void onDisable() {}

    public void onTick(MinecraftClient client) {}
    public void onHudRender(DrawContext context, float tickDelta) {}

    public enum Category {
        HUD("HUD"),
        PVP("PvP / Utility"),
        VISUALS("Visuals"),
        WORLD("World / QoL"),
        CLIENT("Client");

        public final String displayName;
        Category(String displayName) {
            this.displayName = displayName;
        }
    }
}
