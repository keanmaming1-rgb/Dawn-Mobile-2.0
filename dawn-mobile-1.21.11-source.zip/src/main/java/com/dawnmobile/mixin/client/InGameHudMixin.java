package com.dawnmobile.mixin.client;

import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Placeholder for future HUD modifications.
 * Most HUD drawing is currently done via HudRenderCallback in the client entrypoint.
 */
@Mixin(InGameHud.class)
public class InGameHudMixin {
}
