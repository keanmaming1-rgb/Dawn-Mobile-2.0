package com.dawnmobile.mixin.client;

import net.minecraft.client.input.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Placeholder for future input-related modules (e.g. more advanced Toggle Sprint).
 */
@Mixin(KeyboardInput.class)
public class KeyboardInputMixin {
}
